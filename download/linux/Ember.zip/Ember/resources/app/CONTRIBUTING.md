# Contributing
If you would like to contribute, please follow these steps:
1. Fork the respository.
2. Clone your respository to your computer.
3. Make changes! Fix issues, add stuff, etc.
4. Add, commit, and push to your fork.
5. Lastly, submit a pull request! Please describe what you are fixing/adding.
