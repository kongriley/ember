# Ember
A safer, more reliable web browser.

## Installation
Download the latest release:
* OS X
* Windows

## Installing Dev Builds
Make sure you have [Node.js](https://nodejs.org) and [Electron](http://electron.atom.io) installed, then execute the commands:
```
$ git clone https://github.com/mcparadox/ember.git
$ cd Ember
$ npm install && npm start
```
